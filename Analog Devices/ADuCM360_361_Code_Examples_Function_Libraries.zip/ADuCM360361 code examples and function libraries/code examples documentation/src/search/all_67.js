var searchData=
[
  ['general_20purpose_20timer',['General Purpose Timer',['../a00106.html',1,'']]],
  ['gptbsy',['GptBsy',['../a00106.html#gad0c9a626bcc9c25689cab8c17b0d2b0c',1,'GptBsy(ADI_TIMER_TypeDef *pTMR):&#160;GptLib.c'],['../a00106.html#gad0c9a626bcc9c25689cab8c17b0d2b0c',1,'GptBsy(ADI_TIMER_TypeDef *pTMR):&#160;GptLib.c']]],
  ['gptcaprd',['GptCapRd',['../a00106.html#ga31a12cc175700c22e4b630e28e5008a1',1,'GptCapRd(ADI_TIMER_TypeDef *pTMR):&#160;GptLib.c'],['../a00106.html#ga31a12cc175700c22e4b630e28e5008a1',1,'GptCapRd(ADI_TIMER_TypeDef *pTMR):&#160;GptLib.c']]],
  ['gptcapsrc',['GptCapSrc',['../a00106.html#ga3c59d64917a3e57045836f317934ec68',1,'GptCapSrc(ADI_TIMER_TypeDef *pTMR, int iTCapSrc):&#160;GptLib.c'],['../a00106.html#ga3c59d64917a3e57045836f317934ec68',1,'GptCapSrc(ADI_TIMER_TypeDef *pTMR, int iTCapSrc):&#160;GptLib.c']]],
  ['gptcfg',['GptCfg',['../a00106.html#ga7b7b626eade0baf50d278b78e3fadc6d',1,'GptCfg(ADI_TIMER_TypeDef *pTMR, int iClkSrc, int iScale, int iMode):&#160;GptLib.c'],['../a00106.html#ga7b7b626eade0baf50d278b78e3fadc6d',1,'GptCfg(ADI_TIMER_TypeDef *pTMR, int iClkSrc, int iScale, int iMode):&#160;GptLib.c']]],
  ['gptclrint',['GptClrInt',['../a00106.html#ga4fa7d35375e0de6440fbdbd50f2809eb',1,'GptClrInt(ADI_TIMER_TypeDef *pTMR, int iSource):&#160;GptLib.c'],['../a00106.html#ga4fa7d35375e0de6440fbdbd50f2809eb',1,'GptClrInt(ADI_TIMER_TypeDef *pTMR, int iSource):&#160;GptLib.c']]],
  ['gptld',['GptLd',['../a00106.html#gabcc76978f595c6fa61ebe549f94054a2',1,'GptLd(ADI_TIMER_TypeDef *pTMR, int iTLd):&#160;GptLib.c'],['../a00106.html#gabcc76978f595c6fa61ebe549f94054a2',1,'GptLd(ADI_TIMER_TypeDef *pTMR, int iTLd):&#160;GptLib.c']]],
  ['gptlib_2ec',['GptLib.c',['../a00056.html',1,'']]],
  ['gptlib_2eh',['GptLib.h',['../a00057.html',1,'']]],
  ['gptsta',['GptSta',['../a00106.html#ga6c977d0d5e046fa6499734a968af0e20',1,'GptSta(ADI_TIMER_TypeDef *pTMR):&#160;GptLib.c'],['../a00106.html#ga6c977d0d5e046fa6499734a968af0e20',1,'GptSta(ADI_TIMER_TypeDef *pTMR):&#160;GptLib.c']]],
  ['gptval',['GptVal',['../a00106.html#gad681c48feb3e58f799dded09932f8c0c',1,'GptVal(ADI_TIMER_TypeDef *pTMR):&#160;GptLib.c'],['../a00106.html#gad681c48feb3e58f799dded09932f8c0c',1,'GptVal(ADI_TIMER_TypeDef *pTMR):&#160;GptLib.c']]]
];
