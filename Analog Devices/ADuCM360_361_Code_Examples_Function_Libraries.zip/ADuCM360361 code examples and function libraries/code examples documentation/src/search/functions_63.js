var searchData=
[
  ['clearrststa',['ClearRstSta',['../a00112.html#gaa2690342f56a67e2f959bc1d1eb3789b',1,'ClearRstSta(int iStaClr):&#160;RstLib.c'],['../a00112.html#gaa2690342f56a67e2f959bc1d1eb3789b',1,'ClearRstSta(int iStaClr):&#160;RstLib.c']]],
  ['clkcfg',['ClkCfg',['../a00101.html#ga8a1907d005116e9e8bc7ef367732543c',1,'ClkCfg(int iCd, int iClkSrc, int iSysClockDiv, int iClkOut):&#160;ClkLib.c'],['../a00101.html#ga8a1907d005116e9e8bc7ef367732543c',1,'ClkCfg(int iCd, int iClkSrc, int iSysClockDiv, int iClkOut):&#160;ClkLib.c']]],
  ['clkdis',['ClkDis',['../a00101.html#gaa6be6581650a62352d3b0ba4a25e728e',1,'ClkDis(int iClkDis):&#160;ClkLib.c'],['../a00101.html#gaa6be6581650a62352d3b0ba4a25e728e',1,'ClkDis(int iClkDis):&#160;ClkLib.c']]],
  ['clksel',['ClkSel',['../a00101.html#ga511cc004a6168558eae170d94be0a275',1,'ClkSel(int iSpiCd, int iI2cCd, int iUrtCd, int iPwmCd):&#160;ClkLib.c'],['../a00101.html#ga511cc004a6168558eae170d94be0a275',1,'ClkSel(int iSpiCd, int iI2cCd, int iUrtCd, int iPwmCd):&#160;ClkLib.c']]]
];
