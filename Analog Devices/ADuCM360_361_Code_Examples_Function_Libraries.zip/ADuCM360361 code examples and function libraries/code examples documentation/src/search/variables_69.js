var searchData=
[
  ['itm_5frxbuffer',['ITM_RxBuffer',['../a00127.html#gacf1fe3063cedf11b6e6f7cb0dd7c1a51',1,'core_cm3.h']]]
];
