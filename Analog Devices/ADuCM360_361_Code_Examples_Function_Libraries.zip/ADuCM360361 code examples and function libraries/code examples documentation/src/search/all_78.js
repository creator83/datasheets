var searchData=
[
  ['xosccfg',['XOSCCfg',['../a00101.html#gafe3b98a612a4edc4a8320f975aabf16c',1,'XOSCCfg(int iXosc):&#160;ClkLib.c'],['../a00101.html#gafe3b98a612a4edc4a8320f975aabf16c',1,'XOSCCfg(int iXosc):&#160;ClkLib.c']]]
];
