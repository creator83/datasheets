var searchData=
[
  ['reset',['Reset',['../a00112.html',1,'']]]
];
