var searchData=
[
  ['adc',['ADC',['../a00100.html',1,'']]]
];
