var searchData=
[
  ['nvic',['NVIC',['../a00119.html#gac8e97e8ce56ae9f57da1363a937f8a17',1,'core_cm3.h']]],
  ['nvic_5fbase',['NVIC_BASE',['../a00119.html#gaa0288691785a5f868238e0468b39523d',1,'core_cm3.h']]]
];
